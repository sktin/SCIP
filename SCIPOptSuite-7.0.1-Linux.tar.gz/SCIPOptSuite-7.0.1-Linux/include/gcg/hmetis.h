#define HMETIS_EXECUTABLE "/nfs/optimi/usr/bin/hmetis"
